package com.comcast.stringinator.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class StatsResult {
    private final Map<String, Integer> inputs;
    
    public String most_popular;
    
    private String longest_input_received;
    
    private char leastOccurredChar;

	public StatsResult(Map<String, Integer> inputs) {
        this.inputs = inputs;
    }

    public Map<String, Integer> getInputs() {
        return inputs;
    }
    
    public String getMost_popular() {
    	
        int maxCount = 0;

        for (Entry<String, Integer> entry : inputs.entrySet()) {
            if (entry.getValue() > maxCount) {
            	most_popular = entry.getKey();
                maxCount = entry.getValue();
            }
        }

		return most_popular;
	}
 
    
    public String getLongestInputReceived() {
    	String longestInputReceived = null;
        int maxLength = 0;

        for (String key : inputs.keySet()) {
            int keyLength = key.length();
            if (keyLength > maxLength) {
                longestInputReceived = key;
                maxLength = keyLength;
            }
        }

        return longestInputReceived;
    }
    
    //Get least occured char from longestInputReceived
    public char getLeastOccurredChar() {
    	String longestInputReceived = getLongestInputReceived();
        if (longestInputReceived == null || longestInputReceived.isEmpty()) {
            return '\0'; // Return null character if no input or longest input is empty
        }

        // Count occurrences of each character in the longest input received
        Map<Character, Integer> charCounts = new HashMap<>();
        for (char c : longestInputReceived.toCharArray()) {
            charCounts.put(c, charCounts.getOrDefault(c, 0) + 1);
        }

        // Find the character with the least occurrences
        char leastOccurredChar = longestInputReceived.charAt(0);
        int leastOccurrences = charCounts.get(leastOccurredChar);
        for (Map.Entry<Character, Integer> entry : charCounts.entrySet()) {
            if (entry.getValue() < leastOccurrences) {
                leastOccurredChar = entry.getKey();
                leastOccurrences = entry.getValue();
            }
        }

		return leastOccurredChar;
	}


}
