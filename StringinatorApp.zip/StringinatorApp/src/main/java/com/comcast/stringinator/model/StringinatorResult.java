package com.comcast.stringinator.model;

public class StringinatorResult {
    private final String input;
    private final Integer length;
    
    private char maxChar;
    private long maxCharCount;
    
    public StringinatorResult(String input, Integer length) {
        this.input = input;
        this.length = length;
        
    }

    public char getMaxChar() {
		return maxChar;
	}

	public void setMaxChar(char maxChar) {
		this.maxChar = maxChar;
	}

	public long getMaxCharCount() {
		return maxCharCount;
	}

	public void setMaxCharCount(long maxCharCount) {
		this.maxCharCount = maxCharCount;
	}


    public Integer getLength() {
        return length;
    }

    public String getInput() {
        return this.input;
    }
}
