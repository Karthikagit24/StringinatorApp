package com.comcast.stringinator.service;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.comcast.stringinator.model.StatsResult;
import com.comcast.stringinator.model.StringinatorInput;
import com.comcast.stringinator.model.StringinatorResult;

@Service
public class StringinatorServiceImpl implements StringinatorService {

    private Map<String, Integer> seenStrings = new HashMap<>();

    @Override
    public StringinatorResult stringinate(StringinatorInput input) {
    	
    	String value = input.getInput().replaceAll("\\s+", "").replaceAll("[^a-zA-Z0-9]", "");
    	seenStrings.compute(value, (k, v) -> (v == null) ? Integer.valueOf(1) : v + 1);
        System.out.println("map"+seenStrings);
       
        Map<Character, Long> charCount = value.chars()
                .mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        Map.Entry<Character, Long> maxEntry = charCount.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .orElse(null);

        StringinatorResult response = new StringinatorResult(input.getInput(), Integer.valueOf(input.getInput().length()));

        if (maxEntry != null) {
            response.setMaxChar(maxEntry.getKey());
            response.setMaxCharCount(maxEntry.getValue());
        } else {
            response.setMaxChar('\0');
            response.setMaxCharCount(0);
        }
        return response;
    }

    @Override
    public StatsResult stats() {
    	
        return new StatsResult(seenStrings);
    }
    

}
