package com.comcast.stringinator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StringinatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
